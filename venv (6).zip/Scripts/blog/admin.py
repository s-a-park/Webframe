from django.contrib import admin
from .models import Post
from .models import Category
# Register your models here.

admin.site.register(Post)

class CategoryAdmin(admin.ModelAdmin):
    prepopulated_fields = {'slug' : ('name',)}   #슬러그를 네임처럼 바꾸기

admin.site.register(Category,CategoryAdmin)