from django.shortcuts import render
from django.views.generic import ListView,DetailView
from .models import Post

# Create your views here.
class PostList(ListView):     #클래스 형태로 가져옴 모델명_List.html 강제로 찾게 되어있음
    model = Post     #'post_list' 변수됨
    template_name = 'blog/post_list.html'   # 자동인거 말고 html 바꾸고 싶을때
    ordering = '-pk'
    #추가로 이것도 포함해서 넘겨라
    #context-Category =
class PostDetail(DetailView):
    model = Post
    template_name = 'blog/post_detail.html'









#def index(request):

   # all 하면 전부 가져옴
 #   posts = Post.objects.all().order_by('-pk') #orderby sql이랑 같음 -pk 하면 역순으로 가져옴

  #  return render(
   #     request,
    #    'blog/index.html',
     #   {
      #      'posts': posts,
     #   }
   # )

#def single_post_page(request,pk):
 #   post = Post.objects.get(pk=pk)       #하나씩만 가져옴 select where id=~~랑 같음 특정 위치 선택 get
  #  return render(
   #     request,
   #     'blog/single_post_page.html',{
   #         'post':post,
#    }
 #)
