from django.urls import path, include
from . import views
urlpatterns = [
    path('',views.landing),
    path('about_me/',views.about_me), #슬러시 위치 조심 꼭 뒤에

]
