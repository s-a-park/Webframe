from django.urls import path, include
from . import views
urlpatterns = [
    path('',views.PostList.as_view()),    #클래스로 가져올때
    path('<int:pk>/' ,views.PostDetail.as_view()),
  #  path('',views.index),  #절대주소 지금 서버/blog/ 상태
    #path('<int:pk>/' ,views.single_post_page),  #서버/blog/숫자경로
    path('category/<str:slug>/',views.category_page),   #함수 형태로 감
    path('create_post/',views.PostCreate.as_view()), #/blog/create_post/
    path('update_post/<int:pk>/',views.PostUpdate.as_view()),   #/blog/update_post/숫자/
]
