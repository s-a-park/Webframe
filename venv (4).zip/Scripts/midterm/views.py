from django.shortcuts import render
from django.views.generic import ListView,DetailView
from .models import Post
from .models import Staff


# Create your views here.
class PostList(ListView):
    model = Post
    template_name = 'midterm/index.html'
    ordering = '-pk'

class PostDetail(DetailView):
  model = Post
template_name ='midterm/index.html'

class PostList2(ListView):
    model = Staff
    template_name = 'midterm/index.html'

class StaffList(ListView):
    model = Staff
    template_name = 'midterm/list.html'
    #staff_list

class StaffCard(DetailView):
    model = Staff
    template_name = 'midterm/name_card.html'

class StaffCard2(DetailView):
    model = Staff
    template_name = 'midterm/name_card2.html'