from django.apps import AppConfig


class SinglePageConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'single_page'
