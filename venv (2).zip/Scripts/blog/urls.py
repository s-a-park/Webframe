from django.urls import path, include
from . import views
urlpatterns = [
    path('',views.PostList.as_view()),    #클래스로 가져올때
  #  path('',views.index),  #절대주소 지금 서버/blog/ 상태
    path('<int:pk>/' ,views.single_post_page),  #서버/blog/숫자경로
]
