from django.shortcuts import render
from django.views.generic import ListView,DetailView,CreateView
from django.contrib.auth.mixins import LoginRequiredMixin,UserPassesTestMixin
from .models import Post, Category


class PostCreate(LoginRequiredMixin,UserPassesTestMixin,CreateView): #form 로그인 상태여야 글작성 가능
    model = Post
    fields = ['title','hook_text','content','head_image','file_upload','category','tags']
    #template_name = 'blog/post_form.html'

    def test_func(self):
        return self.request.user.is_superuser or self.request.user.is_staff
    def form_valid(self, form):
        current_user = self.request.user
        if current_user.is_authenticated and (current_user.is_staff or current_user.is_superuser):
            form.instance.author = current_user
            #not tag
            return super(PostCreate,self).form_valid(form)
        else:
            return redirect('/blog/')



# Create your views here.
class PostList(ListView):     #클래스 형태로 가져옴 모델명_List.html 강제로 찾게 되어있음
    model = Post     #'post_list' 변수됨
    template_name = 'blog/post_list.html'   # 자동인거 말고 html 바꾸고 싶을때
    ordering = '-pk'
    #추가로 이것도 포함해서 넘겨라
    def get_context_date(self,**kwargs):
        context = super(PostList,self).get_context_data()  #포스트 리스트에 이 내용도 같이 넘기고 싶을때
        context['categories'] = Category.objects.all()
        context['no_category_post_count'] = Post.objects.filter(category=None).count()

        return context #자동으로 포스트리스트html로 가고 post_list,categories,no_category_post_count 가 함께 넘어감


    #context-Category
class PostDetail(DetailView):
    model = Post
    template_name = 'blog/post_detail.html'

    def get_context_date(self,**kwargs):
        context = super(PostDetail, self).get_context_data()  # post에 이 내용도 같이 넘기고 싶을때
        context['categories'] = Category.objects.all()
        context['no_category_post_count'] = Post.objects.filter(category=None).count()

        return context  # 자동으로 포스트디테일html로 가고 post,categories,no_category_post_count 가 함께 넘어감



def category_page(request, slug):
    if slug == 'no_category':   #/blog/category/no_category/ (미분류)
        category = '미분류'
        post_list = Post.objects.filter(category=None)
    else:
        category = Category.object.get(slug=slug)  # /blog/category/slug (프로그래밍, 웹개발, 문화예술 ,라이프스타일)
        post_list = Post.objects.filter(category=category)

    return render(
        request,
        'blog/post_list.html',{
            'post_list':post_list,
            'categories':Category.objects.all(),
            'no_category_post_count':Post.objects.filter(category=None).count(),
            'category':category,
        }
    )





#def index(request):

   # all 하면 전부 가져옴
 #   posts = Post.objects.all().order_by('-pk') #orderby sql이랑 같음 -pk 하면 역순으로 가져옴

  #  return render(
   #     request,
    #    'blog/index.html',
     #   {
      #      'posts': posts,
     #   }
   # )

#def single_post_page(request,pk):
 #   post = Post.objects.get(pk=pk)       #하나씩만 가져옴 select where id=~~랑 같음 특정 위치 선택 get
  #  return render(
   #     request,
   #     'blog/single_post_page.html',{
   #         'post':post,
#    }
 #)
